{!! $post->keyword->name !!} {!! $post->keyword->sentences(1) !!}
